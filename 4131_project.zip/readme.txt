Steps for running:
1) unzip the file
2) run npm install in the terminal from that location
3) run node server.js in the terminal
4) Go to http://localhost:3006/home

Note: All tasks can be viewed by clicking on home in the nav bar but the category wise tasks can be viewed through the links on the side bar

Things I would like to improve on in the future:
1) Add colors along with each category and priority to convey information redundantly through colors
2) Style the cancel buttons differently than the add buttons
3) Add feedback when a task is added or deleted
4) Set the default value to 1) the filter that was just selected and 2) the current category page when adding a new task
5) Display error messages on the website