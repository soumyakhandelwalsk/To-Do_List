`ssh khand080@csel-kh1250-08.cselabs.umn.edu`

This is the steps I intend to follow.
1. Open a terminal for port forwarding
   
   `ssh -L 127.0.0.1:3308:cse-mysql-classes-01.cse.umn.edu:3306 khand080@csel-kh1250-11.cselabs.umn.edu`
   
   This will just sort of work for me because I setup "passwordless SSH" years ago.
   You should anticipate SSH connection problems

2. Open up another terminal and connect to mysql database

   `mysql -h127.0.0.1 -uC4131F22U51 -P3306 C4131F22U51 -p`
   
   If you're just running code on the cselabs machines themselves then you might want
   
   `mysql -hcse-mysql-classes-01.cse.umn.edu -uC4131F22U51 -P3306 C4131F22U51 -p`
   
   either way -- next step is enter password

   Password: Mystery!!database
   
3. Basic "looking around" commands
   * All commands are terminated with semicolon as a general rules
   * `show databases;` (which databases do I have access to on this server)
   * `show tables;` (which tables do I have on the current database)
   * `desc <table>;` (describe a specific table)

4. Create our first table

   ```
   create table Contacts (
     contact_id int not null auto_increment,
     name text not null,
	 description text not null,
	 email text,
	 website text,
	 image_url text not null,
	 primary key(contact_id)
   );
   ```
   
   Delete
   `drop table Contacts`
   
   
   Re-add with location
   
   

   ```
   create table Contacts (
     contact_id int NOT NULL auto_increment,
     name text CHARACTER SET utf8 NOT NULL ,
	 location text CHARACTER SET utf8 NOT NULL ,
	 description text CHARACTER SET utf8 NOT NULL,
	 email text CHARACTER SET utf8,
	 website text CHARACTER SET utf8,
	 image_url text CHARACTER SET utf8 not null ,
	 primary key(contact_id)
   );
   ```
   
5. Looking into the table
   
   `desc Contacts;` (note -- case sensative)
   `select * from Contacts;` (get everything)

6. Add Data

	`insert into Contacts (name, location, description, image_url) values ("Daniel Kluver", "389 Sheperd Labs\n100 Union St SE\nMinneapolis, MN 55455", "Course Instructor CSCI 4131 Fall 2022", "/resources/images/Shepherd.jpg");`

	and update it.
	`update Contacts SET email = "kluve018@umn.edu", website="https://cse.umn.edu/cs/daniel-kluver" where contact_id=1;`
	
	and delete it.
	`delete from Contacts where contact_id=1;`

7. Add more data.

    ```
	insert into Contacts (name, location, description, image_url, email) values ("Daniel Kluver", "389 Sheperd Labs\n100 Union St SE\nMinneapolis, MN 55455", "Course Instructor CSCI 4131 Fall 2022", "/resources/images/Shepherd.jpg", "kluve018@umn.edu");
	insert into Contacts (name, location, description, image_url, email) values ("Mats Heimdahl", "4-192C Kenneth H. Keller Hall\n200 Union Street Se\nMinneapolis, MN 55455", "CSE Department Head", "/resources/images/keller.jpg", "heimdahl@umn.edu");
	insert into Contacts (name, location, description, image_url, email) values ("Joseph A. Konstan", "4-192 Kenneth H. Keller Hall\n200 Union Street Se\nMinneapolis, MN 55455", "CSE Associate Dean for Research", "/resources/images/keller.jpg", "konstan@umn.edu");
	insert into Contacts (name, location, description, image_url) values ("Talha Ahsan", "2-209 Kenneth H. Keller Hall\n200 Union Street Se\nMinneapolis, MN 55455", "Fall 22 CSCI 4131 TA", "/resources/images/keller.jpg");
	insert into Contacts (name, location, description, image_url) values ("Chase Johnson", "2-209 Kenneth H. Keller Hall\n200 Union Street Se\nMinneapolis, MN 55455", "Fall 22 CSCI 4131 TA", "/resources/images/keller.jpg");
	```
8. Queries

   `select * from Contacts;` all rows, all columns
   `select name, location from Contacts;` all rows, some columns
   `select name, email from Contacts where email is not null;` some rows some columns
   `select * from Contacts where description = "Fall 22 CSCI 4131 TA";`
