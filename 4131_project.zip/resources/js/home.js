function fieldBasedSort(listElems, field){
  listElems.sort(function(ele1, ele2) {
    var valA, valB;
    if (field === "dateAdded"){
      valA = ele1.id;
      valB = ele2.id;
      console.log(valA, valB)
    }
    else{
      valA = ele1.getElementsByClassName(field)[0];
      valB = ele2.getElementsByClassName(field)[0];
    }
    if (valA && valB){
      if (field !== "dateAdded"){
        valA = valA.textContent;
        valB = valB.textContent;
      }
      if (valA < valB) {
        return -1; 
      }
      if (valA > valB) {
        return 1; 
      }
      return 0; 
    }
    else if (valA){
      return -1;
    }
    else if (valB){
      return 1;
    }
    else{
      return 0;
    }
  });
}

function sortByField(){
  let sortBox = document.getElementById("sort");
  let field = sortBox.options[sortBox.selectedIndex].value;
  let taskList = document.getElementById("taskList");
  let listElems = Array.from(taskList.getElementsByTagName("li"));
  let extra = listElems.splice(-2,2);
  fieldBasedSort(listElems, field);

  let list = taskList.getElementsByTagName("ul")[0];
  for (let i = 0; i<listElems.length; i++){
    list.appendChild(listElems[i]);
  }
  list.appendChild(extra[0]);
  list.appendChild(extra[1]);
}

// async function deleteTaskHandler(id){
//   try{
//     console.log()
//     let res = await fetch("/api/task/"+id, {method:"DELETE"});
//     if (!res.ok){
//       console.log("Could not delete task " + id)
//     }
//     else{
//       let task = document.getElementById(id);
//       task.remove();
//     }
//   }
//   catch{
//     console.log("Something went wrong");
//   }
// }

async function completionStatusHandler(id, checked){
  try{
    checked = checked ? 1: 0;
    const options = {
      method: "PUT",
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({"completed":checked})
    }
    let res = await fetch("/api/task/"+id, options);
    if (!res.ok){
      console.log("Could not update task completion status of task " + id)
    }
  }
  catch{
    console.log("Something went wrong");
  }
}

function addTaskClickHandlers(){
  let taskList = (document.getElementById("taskList")).getElementsByTagName("li");
  for(let i = 0; i < taskList.length - 2; i++){
    let checkBox = taskList[i].getElementsByTagName("input")[0];
    checkBox.addEventListener("click", () => completionStatusHandler(taskList[i].id, checkBox.checked));
    // let del = taskList[i].getElementsByTagName("button")[0];
    // console.log("Add Task Handler", taskList[i].name, taskList[i].id)
    // del.addEventListener("click", () => deleteTaskHandler(taskList[i].id));
  }
}

function addSortEventHandlers(){
  let sortBox = document.getElementById("sort");
  sortBox.addEventListener("change", sortByField);
}

function newTask(add, form){
  let addTaskButton = document.getElementById(add);
  addTaskButton.style.display = "none";
  let addTaskForm = document.getElementById(form);
  addTaskForm.style.display = "block";
}

function cancelNewTask(add, form){
  let addTaskButton = document.getElementById(add);
  addTaskButton.style.display = "inline";
  let addTaskForm = document.getElementById(form);
  addTaskForm.style.display = "none";
}

function addNewTaskHandler(add, cancel, form){
  let addTask = document.getElementById(add);
  addTask.addEventListener("click", () => newTask(add, form));
  let cancelButton = document.getElementById(cancel);
  cancelButton.addEventListener("click", () => cancelNewTask(add, form));
}

addTaskClickHandlers();
addSortEventHandlers();
addNewTaskHandler("addTask", "cancel", "newTaskForm");
addNewTaskHandler("addCategory", "cancelCategory", "addCategoryForm");