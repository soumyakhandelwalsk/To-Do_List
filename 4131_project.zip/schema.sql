-- create task table
create table tasks (
    task_id int auto_increment,
    name varchar(100) not null,
    description text,
    category varchar(50) not null,
    dueDate varchar(10),
    priority varchar(15) not null,
    completed int not null default 0, 
    primary key(task_id)
);

-- create category table
create table categories (
    name varchar(50) not null,
    primary key(name)
);

-- create priority table
create table priorities (
    priority_id varchar(15) not null,
    primary key(priority_id)
);

-- add category command example

insert into categories values ("No Category");

-- get data command example

select * from contact_me;

select * from contact_me where category = "question";