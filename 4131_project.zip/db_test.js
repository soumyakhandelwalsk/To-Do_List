// This is an entirely fake version of this database file.

const categories = [
  {name: 'No Category'},
  {name: 'Personal'},
  {name: 'Assignments'},
  {name: 'Tests'}
]

const priorities = [
  {priority_id: "Priority 4"},
  {priority_id: "Priority 3"},
  {priority_id: "Priority 2"},
  {priority_id: "Priority 1"}
]

const tasks = [
  {task_id: 1, name: "Test", description: "Test Description", category: "No Category", dueDate: null, priority: "Priority 4", completed: 1},
  {task_id: 2, name: "Test2", description: "Test Description", category: "No Category", dueDate: null, priority: "Priority 3", completed: 0}
]

async function getCategories() {
  return categories;
}
exports.getCategories = getCategories;

async function getPriorities() {
  return priorities;
}
exports.getPriorities = getPriorities;

async function getTasks(category) {
  if (category){
    let newList = [];
    for (let i=0; i<tasks.length; i++){
      if (tasks[i].category === category){
        newList.push(tasks[i]);
      }
    }
    return newList;
  }
  else{
    return tasks;
  }
  
}
exports.getTasks = getTasks;

async function addTask(name, description, category, dueDate, priority) {
  tasks.push({task_id: 3, name:name, description:description, category:category, dueDate:dueDate, priority:priority, completed: 0})
}
exports.addTask = addTask;

async function changeTaskCompleted(task_id, checked) {
  for (task of tasks){
    if (task.task_id === task_id){
      task.completed = checked;
    }
  }
}
exports.changeTaskCompleted = changeTaskCompleted;

async function deleteTask(task_id) {
  for (let i=0; i<tasks.length; i++){
    if (tasks[i].task_id === task_id){
      tasks.splice(i, 1);
    }
  }
}
exports.deleteTask = deleteTask;

async function addCategory(category) {
  categories.push({name: category})
}
exports.addCategory = addCategory;

async function getFilterTasks(category, field, value) {
  let newList = [], results = [];
  if (category){
    newList = await getTasks(category)
  }
  else{
    newList = tasks;
  }
  console.log(newList)
  // console.log("field", newList[0][field], "Val", value)
  for (let i=0; i<newList.length; i++){
    if (newList[i][field] === value){
      results.push(newList[i]);
    }
  }
  console.log("Results", results)
  return results;
}
exports.getFilterTasks = getFilterTasks;