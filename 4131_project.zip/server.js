const express = require('express');
const app = express();
const port = 3006;

var db = require("./db");

app.use('/resources', express.static('resources'));
app.use(express.urlencoded({extended:true}));
app.use(express.json());

app.set("views", "templates");
app.set("view engine", "pug");

app.get("/", (req, res) => {
  res.redirect("/home");
});


app.get('/home', async function(req, res) {
  let categories = [], priorities = [], tasks = [];
  try {
    categories = await db.getCategories();
    priorities = await db.getPriorities();
    tasks = await db.getTasks(null);
  }
  catch (e){
    console.log("Error", e);
  }
  finally {
    res.render("home.pug", {categories: categories, priorities: priorities, tasks: tasks});
  }
});

app.post('/home', async function(req, res) {
  let categories = [], priorities = [], tasks = [];
  const filter = req.body.filter  || "none";
  try {
    if (filter === "none"){
      tasks = await db.getTasks(null);
    }
    else{
      tasks = await db.getFilterTasks(null, Number(filter));
    }
    categories = await db.getCategories();
    priorities = await db.getPriorities();
  }
  catch (e) {
    console.log("Error", e);
  }
  finally {
    res.render("home.pug", {categories: categories, priorities: priorities, tasks: tasks});
  }
});

app.get('/category/:categoryName', async function(req, res) {
  let categories = [], priorities = [], tasks = [];
  try {
    categories = await db.getCategories();
    priorities = await db.getPriorities();
    tasks = await db.getTasks(req.params.categoryName);
  }
  catch (e){
    console.log("Error", e);
  }
  finally {
    res.render("home.pug", {categories: categories, priorities: priorities, tasks: tasks, selectedCategory: req.params.categoryName});
  }
});

app.post('/category/:categoryName', async function(req, res) {
  let categories = [], priorities = [], tasks = [];
  const filter = req.body.filter  || "none";
  try {
    if (filter === "none"){
      tasks = await db.getTasks(req.params.categoryName);
    }
    else{
      tasks = await db.getFilterTasks(req.params.categoryName, Number(filter));
    }
    categories = await db.getCategories();
    priorities = await db.getPriorities();
  }
  catch {
    console.log("Error getting values from database.");
  }
  finally {
    res.render("home.pug", {categories: categories, priorities: priorities, tasks: tasks, selectedCategory: req.params.categoryName});
  }
});

app.post('/addTask', async function(req, res) {
  const name = req.body.name || null;
  const description = req.body.description || null;
  const category = req.body.category  || null;
  const dueDate = req.body.dueDate || null;
  const priority= req.body.priority  || null;

  let feedback = "";
  try {
    await db.addTask(name, description, category, dueDate, priority);
    feedback = "Your message has been received!";
  }
  catch (e) {
    feedback = e.sqlMessage;
  }
  finally {
    console.log(feedback);
    res.redirect("/home");
  }
});

app.post('/addTask/:category', async function(req, res) {
  const name = req.body.name || null;
  const description = req.body.description || null;
  const category = req.body.category  || null;
  const dueDate = req.body.dueDate || null;
  const priority= req.body.priority  || null;

  let feedback = "";
  try {
    await db.addTask(name, description, category, dueDate, priority);
    feedback = "Your message has been received!";
  }
  catch (e) {
    feedback = e.sqlMessage;
  }
  finally {
    console.log(feedback);
    res.redirect("/category/"+req.params.category);
  }
});

app.post('/deleteTask/:taskID', async function(req, res) {
  try {
    await db.deleteTask(req.params.taskID);
  }
  catch (e) {
    console.log(e);
  }
  finally {
    res.redirect("/home");
  }
});

app.post('/deleteTask/:category/:taskID', async function(req, res) {
  try {
    await db.deleteTask(req.params.taskID);
  }
  catch (e) {
    console.log(e);
  }
  finally {
    res.redirect("/category/"+req.params.category);
  }
});

app.post('/addCategory', async function(req, res) {
  const newCategory = req.body.newCategory || null;

  let feedback = "";
  try {
    await db.addCategory(newCategory);
    feedback = "Your message has been received!";
  }
  catch (e) {
    feedback = e.sqlMessage;
  }
  finally {
    console.log(feedback);
    res.redirect("/category/"+newCategory);
  }
});

app.put('/api/task/:taskID', async function(req, res) {
  try{
    await db.changeTaskCompleted(Number(req.params.taskID), Number(req.body.completed));
    res.sendStatus(204);
  }
  catch (e){
    console.log("Error", e);
    res.sendStatus(404);
  }
});

// app.delete('/api/task/:taskID', async function(req, res) {
//   // change status codes
//   try{
//     console.log(req.params.taskID)
//     await db.deleteTask(Number(req.params.taskID));
//     res.sendStatus(204);
//   }
//   catch (e){
//     console.log("Error", e);
//     res.sendStatus(404);
//   }
// });

app.get('/attributions', async function (req,res){
  res.render("attributions.pug");
});

app.listen(port, () => {
  console.log(`App listening on port ${port}`);
});

