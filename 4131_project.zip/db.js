var mysql = require("mysql")

var connPool = mysql.createPool({
  connectionLimit : 5,
  host: "cse-mysql-classes-01.cse.umn.edu", //"127.0.0.1"
  user: "C4131F22U51",
  database: "C4131F22U51",
  password: "Mystery!!database",
  port: 3306 //3308
});

async function getCategories() {
  return new Promise (( resolve , reject) => {
    connPool.query("select * from categories", (error , results) => {
      if (error) {
        console.log("cat")
        reject(error);
      } else {
        resolve(results);
      }
    });
  });
}
exports.getCategories = getCategories;

async function getPriorities() {
  return new Promise (( resolve , reject) => {
    connPool.query("select * from priorities", (error , results) => {
      if (error) {
        console.log("pri")
        reject(error);
      } else {
        resolve(results);
      }
    });
  });
}
exports.getPriorities = getPriorities;

async function getTasks(category) {
  let sql = "select * from tasks";
  if (category){
    sql += " where category = " + connPool.escape(category);
  }
  return new Promise (( resolve , reject) => {
    connPool.query(sql, (error , results) => {
      if (error) {
        console.log("task")
        reject(error);
      } else {
        resolve(results);
      }
    });
  });
}
exports.getTasks = getTasks;

async function addTask(name, description, category, dueDate, priority) {
  let sql = "insert into tasks (name, description, category, dueDate, priority) values(?, ?, ?, ?, ?)";
  return new Promise (( resolve , reject) => {
    connPool.query(sql, [name, description, category, dueDate, priority], (error , results) => {
      if (error) {
        reject(error);
      } else {
        resolve(results);
      }
    });
  });
}
exports.addTask = addTask;

async function changeTaskCompleted(task_id, checked) {
  let sql = "update tasks set completed=? where task_id=?";
  return new Promise (( resolve , reject) => {
    connPool.query(sql, [checked, task_id], (error , results) => {
      if (error) {
        reject(error);
      } else {
        resolve(results);
      }
    });
  });
}
exports.changeTaskCompleted = changeTaskCompleted;

async function deleteTask(task_id) {
  let sql = "delete from tasks where task_id=?";
  return new Promise (( resolve , reject) => {
    connPool.query(sql, [task_id], (error , results) => {
      if (error) {
        reject(error);
      } else {
        resolve(results);
      }
    });
  });
}
exports.deleteTask = deleteTask;

async function addCategory(category) {
  let sql = "insert into categories values(?)";
  return new Promise (( resolve , reject) => {
    connPool.query(sql, [category], (error , results) => {
      if (error) {
        reject(error);
      } else {
        resolve(results);
      }
    });
  });
}
exports.addCategory = addCategory;

async function getFilterTasks(category, value) {
  let sql = "select * from tasks";
  if (category){
    sql += " where category = " + connPool.escape(category) + " and ";
  }
  else{
    sql += " where ";
  }
  sql += "completed = " + connPool.escape(value);
  return new Promise (( resolve , reject) => {
    connPool.query(sql, (error , results) => {
      if (error) {
        reject(error);
      } else {
        resolve(results);
      }
    });
  });
}
exports.getFilterTasks = getFilterTasks;

async function deleteTask(taskId) {
  let sql = "delete from tasks where task_id =" + connPool.escape(taskId);
  return new Promise (( resolve , reject) => {
    connPool.query(sql, (error , results) => {
      if (error) {
        reject(error);
      } else {
        resolve(results);
      }
    });
  });
}
exports.deleteTask = deleteTask;